#include <iostream>

using namespace std;

int main()
{

	cout << "Welcome to Programming Fundamentals" << endl;
	cout << "Name :JACK" << endl;
	cout << "Roll#: XX-XXXX" << endl;
	cout << "Degree: BS(CS)" << endl;
	cout << "Section: D" << endl;
	cout << "Lab: 03" << endl;

	return 0;

}