/*#include <iostream>

using namespace std;

int main()

{
	int height;
	int width;
	int area;

	cout << "Enter the height: " << endl;
	cin >> height;

	cout << "Enter the width: " << endl;
	cin >> width;

	area= height * width;
	cout << "Area=" << area;
	system("pause");
	

	return 0;
}*/
