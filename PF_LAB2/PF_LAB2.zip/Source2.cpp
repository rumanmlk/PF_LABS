/*#include <iostream>

using namespace std;

int main()
{
	int A;
	int B;
	int Product;
	int Sum;
	double Square;
	double Difference;
	double Division;
	double Modulo;

	cout << "Enter the First number: ";
	cin >> A;

	cout << "Enter the second number: ";
	cin >> B;

	Product= A * B;
	cout << "Product=" << Product << endl;

	Sum= A + B;
	cout << "Sum= " << Sum << endl;

	cout << "Square= " << A*A << ',' << B*B << endl;

	Difference= A-B;
	cout << "Difference= " << Difference << endl;

	Division= double(A)/double(B);
	cout << "Division= " << Division << endl;

	Modulo =A % B;
	cout << "Modulo= " << Modulo << endl;

	system("pause");

	return 0;

}*/