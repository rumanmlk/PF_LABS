/*#include <iostream>

using namespace std;

int main()
{
	char character1;
	char character2;
	cout << "INPUT= ";
	cin >> character1 >> character2;
	cout << "OUTPUT=";
	cout <<static_cast<int>(character1) << static_cast<int>(character2);
	system("pause");

	
	return 0;
}*/
