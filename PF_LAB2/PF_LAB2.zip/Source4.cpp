/*#include <iostream>
#include <string>

using namespace std;

int main()
{
	int x, y;
	cout << "Enter the x= ";
	cin >> x;
	cout << "Enter the y=";
	cin >> y;
	       x = x + y;
		   y = x - y;
		   x = x - y;
    cout << "x= " << x << endl;
	cout << "y= " << y << endl;
	system("pause");
}*/
