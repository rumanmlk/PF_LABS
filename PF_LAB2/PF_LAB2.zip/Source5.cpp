/*#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
	int a, b,sum;
	cin >> a >> b;
	sum = -a-b;
	sum *= -1;
	cout << "Sum : " << sum;
	system("pause");
}*/