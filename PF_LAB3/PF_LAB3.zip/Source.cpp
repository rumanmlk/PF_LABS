/*#include <iostream>

using namespace std;

int main()
{

   double weightinkg;
   double weightinlb;

   cout << "Enter the weight in kilograms= ";
   cin >> weightinkg;

   weightinlb = 2.2 * weightinkg;

   cout << "Your weight in pounds= " << weightinlb <<endl;

   system("pause");

   return 0;

}*/