/*#include <iostream>

using namespace std;

int main()
{

	double num;

	cout << "Enter the number= ";
	cin >> num;

	if(num>0)
	{
		cout << "The number is positive" << endl;
	}
	else
	{
		cout << "The number is negative" << endl;
	}
	
	system("pause");

	return 0;

}*/