/*#include <iostream>

using namespace std;

int main()
{

	char alphabet;

	cout << "Enter the alphabet= ";
	cin >> alphabet;

	if(alphabet == 'a' || alphabet == 'A' || alphabet == 'e'
		|| alphabet == 'E' || alphabet == 'i' || alphabet == 'I'
		|| alphabet == 'o' || alphabet == 'O'|| alphabet == 'u' 
		|| alphabet == 'U')
	{
		cout << "The alphabet is vowel" << endl;
	}

	else
	{
		cout << "The alphabet is consonant" << endl;
	}

	system("pause");

	return 0;
}*/
