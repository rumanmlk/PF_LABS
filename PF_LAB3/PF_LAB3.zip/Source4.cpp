/*include <iostream>

using namespace std;

int main()
{

	int year;

	cout << "Enter the year= ";
	cin >> year;
	
	if(year%4 == 0)
	{
		if(year%100 == 0)
		{
			if (year%400 ==0)
			{
				cout << "It is a leap year" << endl;
				cout << "January: 31 days" << endl;
				cout << "February: 29 days" << endl;
				cout << "March: 31 days" << endl;
				cout << "April: 30 days" << endl;
				cout << "May: 31 days" << endl;
				cout << "June: 30 days" << endl;
				cout << "July: 31 days" << endl;
				cout << "August: 31 days" << endl;
				cout << "September: 30 days" << endl;
				cout << "October: 31 days" << endl;
				cout << "November: 30 days" << endl;
				cout << "December: 31 days" << endl;
			}
			else
			{
				cout << "It is not a leap year" << endl;
				cout << "January: 31 days" << endl;
				cout << "February: 28 days" << endl;
				cout << "March: 31 days" << endl;
				cout << "April: 30 days" << endl;
				cout << "May: 31 days" << endl;
				cout << "June: 30 days" << endl;
				cout << "July: 31 days" << endl;
				cout << "August: 31 days" << endl;
				cout << "September: 30 days" << endl;
				cout << "October: 31 days" << endl;
				cout << "November: 30 days" << endl;
				cout << "December: 31 days" << endl;
			}
		}
		else
		{
		        cout << "It is a leap year" << endl;
				cout << "January: 31 days" << endl;
				cout << "February: 29 days" << endl;
				cout << "March: 31 days" << endl;
				cout << "April: 30 days" << endl;
				cout << "May: 31 days" << endl;
				cout << "June: 30 days" << endl;
				cout << "July: 31 days" << endl;
				cout << "August: 31 days" << endl;
				cout << "September: 30 days" << endl;
				cout << "October: 31 days" << endl;
				cout << "November: 30 days" << endl;
				cout << "December: 31 days" << endl;
		}
	}
	else
	{
	            cout << "It is not a leap year" << endl;
				cout << "January: 31 days" << endl;
				cout << "February: 28 days" << endl;
				cout << "March: 31 days" << endl;
				cout << "April: 30 days" << endl;
				cout << "May: 31 days" << endl;
				cout << "June: 30 days" << endl;
				cout << "July: 31 days" << endl;
				cout << "August: 31 days" << endl;
				cout << "September: 30 days" << endl;
				cout << "October: 31 days" << endl;
				cout << "November: 30 days" << endl;
				cout << "December: 31 days" << endl;
	}

			
		system("pause");

		return 0;
}*/
	


	
	
		
		


			


	

	
	