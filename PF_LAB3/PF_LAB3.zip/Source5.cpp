/*#include <iostream>

using namespace std;

int main()
{

	int num;
	cout << "Enter the number from 1 to 7= ";
	cin >> num;

	if (num == 1)
	{
		cout << "Today is Friday" << endl;
	}
	else if (num == 2)
	{
		cout << "Today is Saturday" << endl;
	}
	else if (num == 3)
	{
		cout << "Today is Sunday " << endl;
	}
	else if (num == 4)
	{
		cout << "Today is Monday" << endl;
	}
	else if (num == 5)
	{
		cout << "Today is Tuesday" << endl;
	}
	else if (num == 6)
	{
		cout << "Today is Wednesday" << endl;
	}
	else 
	{
		cout << "Today is Thursday" << endl;
	}
	
	system("pause");

	return 0;
}*/