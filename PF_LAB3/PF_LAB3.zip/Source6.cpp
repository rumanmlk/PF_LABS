/*#include <iostream>

using namespace std;

int main()
{

	int a;
	int b;
	int c;

	cout << "a= ";
	cin >> a;

	cout << "b= ";
	cin >> b;

	cout << "c= ";
	cin >> c;

	if (a!=0)
	{
		if(b % a == 0 && c % a == 0)
		{
			cout << "a is common divisor of b and c" << endl;
		}
		else
		{
			cout << "a is not a common divisor of b and c" << endl;
		}
	}
	else
	{
		cout << "a is equal to zero" << endl;
	}

		system("pause");

		return 0;
}*/
	

